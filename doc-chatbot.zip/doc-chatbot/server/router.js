const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');
const { rateLimit } = require('express-rate-limit');

const config = require('./config');
const store = require('./services/vectorStore');
const { answerQuestion } = require('./services/rag');
const { readStatus } = require('./services/folderSync');

/**
 * Creates the document-chat router.
 *
 *   app.use('/api/docchat', createDocChatRouter({ authMiddleware: yourAuth }));
 *
 * Routes:
 *   POST   /chat                 { question, history }  -> { answer, sources }
 *   GET    /documents            (admin)  what has been learned + the state of each file
 *   POST   /documents            (admin)  upload one or more PDFs (multipart field "files")
 *   DELETE /documents/:name      (admin)  delete a PDF from the top level of the folder
 *
 * Uploading and deleting only change the documents folder. The folder sync
 * (AUTO_SYNC=true, or `npm run watch`) does the learning and forgetting.
 */
function createDocChatRouter({ authMiddleware } = {}) {
  const router = express.Router();
  router.use(express.json({ limit: '100kb' }));

  // ---------- Chat ----------
  const chatLimiter = rateLimit({
    windowMs: 60 * 1000,
    limit: config.chatRateLimitPerMinute,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many questions. Please wait a minute and try again.' },
  });

  const chatMiddleware = [chatLimiter];
  if (authMiddleware) chatMiddleware.unshift(authMiddleware);

  let inFlight = 0;

  router.post('/chat', ...chatMiddleware, async (req, res) => {
    const { question, history } = req.body || {};

    if (typeof question !== 'string' || !question.trim()) {
      return res.status(400).json({ error: 'Enter a question.' });
    }
    if (question.length > config.maxQuestionChars) {
      return res.status(400).json({ error: `Questions are limited to ${config.maxQuestionChars} characters.` });
    }
    if (inFlight >= config.maxConcurrentChats) {
      return res.status(503).json({ error: 'The assistant is busy. Try again in a moment.' });
    }

    inFlight++;
    try {
      res.json(await answerQuestion(question.trim(), history));
    } catch (err) {
      console.error('[docchat] chat error:', err.message);
      res.status(500).json({ error: 'The assistant could not answer right now. Try again shortly.' });
    } finally {
      inFlight--;
    }
  });

  // ---------- Admin: manage the documents folder ----------
  function requireAdmin(req, res, next) {
    if (!config.adminApiKey) return res.status(404).json({ error: 'Not found' }); // disabled
    const provided = Buffer.from(String(req.get('x-admin-key') || ''));
    const expected = Buffer.from(config.adminApiKey);
    if (provided.length !== expected.length || !crypto.timingSafeEqual(provided, expected)) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    next();
  }

  const safeName = (name) => path.basename(name).replace(/[^\w.\- ]/g, '_');

  const upload = multer({
    storage: multer.diskStorage({
      destination: (req, file, cb) => {
        fs.mkdirSync(config.documentsDir, { recursive: true });
        cb(null, config.documentsDir);
      },
      // Same file name = replaces the old file, which the sync then learns again.
      filename: (req, file, cb) => cb(null, safeName(file.originalname)),
    }),
    limits: { fileSize: 100 * 1024 * 1024, files: 20 },
    fileFilter: (req, file, cb) =>
      /\.pdf$/i.test(file.originalname) ? cb(null, true) : cb(new Error('Only PDF files are allowed.')),
  });

  router.get('/documents', requireAdmin, (req, res) => {
    res.json({ documents: store.list(), sync: readStatus() });
  });

  router.post('/documents', requireAdmin, (req, res) => {
    upload.array('files', 20)(req, res, (err) => {
      if (err) return res.status(400).json({ error: err.message });
      if (!req.files || req.files.length === 0) {
        return res.status(400).json({ error: 'Attach one or more PDFs in the "files" field.' });
      }
      res.status(202).json({
        saved: req.files.map((f) => f.filename),
        note: 'Saved. They will be learned within a few seconds; check GET /documents for progress.',
      });
    });
  });

  router.delete('/documents/:name', requireAdmin, (req, res) => {
    const file = path.join(config.documentsDir, safeName(req.params.name));
    fs.unlink(file, (err) => {
      if (err) return res.status(404).json({ error: 'File not found.' });
      res.json({ deleted: true, note: 'It will be forgotten at the next sync.' });
    });
  });

  return router;
}

module.exports = createDocChatRouter;
