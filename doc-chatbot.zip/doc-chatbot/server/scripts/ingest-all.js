// One-off sync: learn new/changed PDFs, forget deleted ones, then exit.
//   npm run ingest
const { syncOnce } = require('../services/folderSync');

(async () => {
  const summary = await syncOnce({
    onProgress: (source, message) => process.stdout.write(`\r${source}: ${message}          `),
  });
  process.stdout.write('\n');

  if (summary.skipped) {
    console.log('Another sync is already running (the watcher?). Nothing to do.');
    return;
  }
  console.log(
    `Added ${summary.added.length}, updated ${summary.updated.length}, unchanged ${summary.unchanged}, ` +
      `removed ${summary.removed.length}, failed ${summary.failed.length}` +
      (summary.waiting.length ? `, still copying ${summary.waiting.length}` : '')
  );
  if (summary.failed.length) process.exitCode = 1;
})().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
