// Runs the folder sync as its own process (recommended on IIS / when running several API processes).
//   npm run watch
const config = require('../config');
const { startSync } = require('../services/folderSync');

console.log(`Watching ${config.documentsDir} every ${config.syncIntervalMs / 1000}s (Ctrl+C to stop)`);
startSync();
