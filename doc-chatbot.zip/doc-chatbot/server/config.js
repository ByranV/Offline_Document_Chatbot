const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const int = (v, d) => (v === undefined || v === '' ? d : parseInt(v, 10));
const float = (v, d) => (v === undefined || v === '' ? d : parseFloat(v));

module.exports = {
  port: int(process.env.PORT, 4000),
  corsOrigin: process.env.CORS_ORIGIN || 'http://localhost:3000',

  // Ollama (local models)
  ollamaHost: process.env.OLLAMA_HOST || 'http://127.0.0.1:11434',
  chatModel: process.env.CHAT_MODEL || 'llama3.1:8b',
  embedModel: process.env.EMBED_MODEL || 'nomic-embed-text',
  // Context window. Ollama's default is small and silently truncates long prompts.
  numCtx: int(process.env.NUM_CTX, 8192),
  temperature: float(process.env.TEMPERATURE, 0.1),
  requestTimeoutMs: int(process.env.REQUEST_TIMEOUT_MS, 180000),

  // Retrieval
  topK: int(process.env.TOP_K, 5),
  // Minimum cosine similarity (0-1) for a chunk to count as relevant. Tune on your own documents.
  minScore: float(process.env.MIN_SCORE, 0.45),
  chunkChars: int(process.env.CHUNK_CHARS, 1200),
  chunkOverlapChars: int(process.env.CHUNK_OVERLAP_CHARS, 200),

  // Folder sync: watches documentsDir for new, changed and deleted PDFs
  autoSync: (process.env.AUTO_SYNC || 'false').toLowerCase() === 'true', // run the sync inside the API process
  syncIntervalMs: int(process.env.SYNC_INTERVAL_MS, 10000),
  stableDelayMs: int(process.env.STABLE_DELAY_MS, 3000), // a file must stop changing this long before it is read
  autoRemove: (process.env.AUTO_REMOVE || 'true').toLowerCase() === 'true', // forget documents whose PDF was deleted

  // Storage
  documentsDir: process.env.DOCUMENTS_DIR || path.join(__dirname, 'documents'),
  dataDir: process.env.DATA_DIR || path.join(__dirname, 'data'),

  // API protection
  adminApiKey: process.env.ADMIN_API_KEY || '', // empty = admin upload routes disabled
  maxQuestionChars: int(process.env.MAX_QUESTION_CHARS, 1000),
  maxConcurrentChats: int(process.env.MAX_CONCURRENT_CHATS, 3),
  chatRateLimitPerMinute: int(process.env.CHAT_RATE_LIMIT_PER_MINUTE, 20),
};
