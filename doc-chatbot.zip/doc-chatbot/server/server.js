// Standalone runner, handy for testing on its own port.
// To use inside your existing API, mount router.js instead (see README).
const express = require('express');
const cors = require('cors');
const config = require('./config');
const createDocChatRouter = require('./router');
const { startSync } = require('./services/folderSync');
const { health } = require('./services/ollama');

const app = express();
app.use(cors({ origin: config.corsOrigin.split(',').map((s) => s.trim()) }));
app.use('/api/docchat', createDocChatRouter());

app.listen(config.port, async () => {
  console.log(`Doc chatbot API listening on http://localhost:${config.port}/api/docchat`);
  try {
    const status = await health();
    if (!status.ok) {
      console.warn(`Missing Ollama models: ${status.missing.join(', ')}`);
      status.missing.forEach((m) => console.warn(`  run: ollama pull ${m}`));
    } else {
      console.log(`Ollama ready (chat: ${config.chatModel}, embeddings: ${config.embedModel})`);
    }
  } catch (err) {
    console.warn(err.message);
  }

  if (config.autoSync) {
    console.log(`Watching ${config.documentsDir} for PDFs (every ${config.syncIntervalMs / 1000}s)`);
    startSync();
  }
});
