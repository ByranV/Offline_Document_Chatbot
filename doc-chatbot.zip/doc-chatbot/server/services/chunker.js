/**
 * Split one page of text into overlapping chunks, keeping line breaks
 * (which preserves the row structure of simple tables).
 */
function chunkPage(text, { maxChars, overlapChars }) {
  const units = [];
  for (const raw of text.split('\n')) {
    const line = raw.trim();
    if (!line) continue;
    if (line.length <= maxChars) {
      units.push(line);
      continue;
    }
    // Very long line: split on sentences, then hard-split anything still too long.
    for (const sentence of line.split(/(?<=[.!?])\s+/)) {
      for (let i = 0; i < sentence.length; i += maxChars) units.push(sentence.slice(i, i + maxChars));
    }
  }

  const chunks = [];
  let current = [];
  let length = 0;

  for (const unit of units) {
    if (length + unit.length + 1 > maxChars && current.length) {
      chunks.push(current.join('\n'));
      // Carry the last few lines into the next chunk as overlap.
      const carry = [];
      let carried = 0;
      for (let i = current.length - 1; i >= 0; i--) {
        if (carried + current[i].length > overlapChars) break;
        carry.unshift(current[i]);
        carried += current[i].length + 1;
      }
      current = carry;
      length = carried;
    }
    current.push(unit);
    length += unit.length + 1;
  }
  if (current.length) chunks.push(current.join('\n'));

  return chunks;
}

/** pages: string[] -> [{ page (1-based), text }] */
function chunkDocument(pages, options) {
  const out = [];
  pages.forEach((pageText, i) => {
    for (const text of chunkPage(pageText, options)) {
      if (text.length >= 30) out.push({ page: i + 1, text });
    }
  });
  return out;
}

module.exports = { chunkPage, chunkDocument };
