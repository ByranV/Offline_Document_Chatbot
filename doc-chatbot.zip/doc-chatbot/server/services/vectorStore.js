const fs = require('fs');
const path = require('path');
const config = require('../config');

function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

/**
 * Minimal file-backed vector store. Fine for thousands of chunks.
 * Vectors are normalised on insert, so cosine similarity is a plain dot product.
 *
 * The sync process writes this file; the API process only reads it and reloads
 * automatically when the file changes.
 */
class VectorStore {
  constructor(file) {
    this.file = file;
    this.data = { meta: {}, documents: {}, chunks: [] };
    this.mtime = 0;
    this.load();
  }

  load() {
    if (!fs.existsSync(this.file)) return;
    const parsed = JSON.parse(fs.readFileSync(this.file, 'utf8'));
    this.data = { meta: {}, documents: {}, chunks: [], ...parsed };
    this.mtime = fs.statSync(this.file).mtimeMs;
  }

  /** Reload if another process changed the file. Never throws: keeps the old data on error. */
  refreshIfChanged() {
    try {
      if (!fs.existsSync(this.file)) return;
      if (fs.statSync(this.file).mtimeMs !== this.mtime) this.load();
    } catch (err) {
      // The file may be mid-replace; keep using what we have until the next call.
    }
  }

  save() {
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const tmp = `${this.file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.data));
    // On Windows the rename can fail briefly if another process is reading the file.
    for (let attempt = 0; ; attempt++) {
      try {
        fs.renameSync(tmp, this.file);
        break;
      } catch (err) {
        if (attempt >= 5 || !['EPERM', 'EBUSY', 'EACCES'].includes(err.code)) throw err;
        sleepSync(150);
      }
    }
    this.mtime = fs.statSync(this.file).mtimeMs;
  }

  /**
   * If anything that affects the stored vectors changed (embedding model, chunk size),
   * forget everything so every document is learned again. Returns true if data was discarded.
   */
  ensureFingerprint(fingerprint) {
    this.refreshIfChanged();
    if (this.data.meta.fingerprint === fingerprint) return false;
    const hadData = this.data.chunks.length > 0;
    this.data = { meta: { fingerprint }, documents: {}, chunks: [] };
    this.save();
    return hadData;
  }

  has(source) {
    this.refreshIfChanged();
    return !!this.data.documents[source];
  }

  matchesHash(source, hash) {
    this.refreshIfChanged();
    return !!this.data.documents[source] && this.data.documents[source].hash === hash;
  }

  /** True if the stored copy was learned from a file with this exact size and modified time. */
  matchesFile(source, size, mtimeMs) {
    this.refreshIfChanged();
    const d = this.data.documents[source];
    return !!d && d.size === size && d.mtimeMs === mtimeMs;
  }

  /** The file was touched but its content is identical: remember the new timestamp. */
  touchDocument(source, size, mtimeMs) {
    this.refreshIfChanged();
    const d = this.data.documents[source];
    if (!d) return;
    d.size = size;
    d.mtimeMs = mtimeMs;
    this.save();
  }

  /** Map of "page|text" -> vector for a document's current chunks, so unchanged chunks are not re-embedded. */
  getChunkVectors(source) {
    this.refreshIfChanged();
    const map = new Map();
    for (const c of this.data.chunks) {
      if (c.source === source) map.set(`${c.page}|${c.text}`, c.vector);
    }
    return map;
  }

  /**
   * Replace everything stored for a document in one step, so searches keep using
   * the old version until the new one is completely ready.
   * chunks: [{ page, text, vector }]   file: { size, mtimeMs }
   */
  replaceDocument(source, hash, pageCount, chunks, file) {
    this.refreshIfChanged();
    this.data.chunks = this.data.chunks.filter((c) => c.source !== source);
    for (const c of chunks) {
      this.data.chunks.push({ source, page: c.page, text: c.text, vector: normalize(c.vector) });
    }
    this.data.documents[source] = {
      hash,
      size: file.size,
      mtimeMs: file.mtimeMs,
      pages: pageCount,
      chunks: chunks.length,
      ingestedAt: new Date().toISOString(),
    };
    this.save();
  }

  removeDocument(source) {
    this.refreshIfChanged();
    const existed = !!this.data.documents[source];
    delete this.data.documents[source];
    this.data.chunks = this.data.chunks.filter((c) => c.source !== source);
    if (existed) this.save();
    return existed;
  }

  list() {
    this.refreshIfChanged();
    return Object.entries(this.data.documents).map(([name, info]) => ({ name, ...info }));
  }

  /** Returns the top-k chunks scoring at least minScore, best first. */
  search(queryVector, k, minScore) {
    this.refreshIfChanged();
    const q = normalize(queryVector);
    const scored = [];
    for (const c of this.data.chunks) {
      let dot = 0;
      for (let i = 0; i < q.length; i++) dot += q[i] * c.vector[i];
      if (dot >= minScore) scored.push({ source: c.source, page: c.page, text: c.text, score: dot });
    }
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, k);
  }
}

function normalize(vec) {
  let norm = 0;
  for (const x of vec) norm += x * x;
  norm = Math.sqrt(norm) || 1;
  return Array.from(vec, (x) => Math.round((x / norm) * 1e5) / 1e5);
}

module.exports = new VectorStore(path.join(config.dataDir, 'store.json'));
module.exports.VectorStore = VectorStore;
