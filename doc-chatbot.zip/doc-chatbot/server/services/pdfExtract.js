// pdf-parse v1: require the inner file to avoid its debug-mode side effect on require('pdf-parse').
const pdfParse = require('pdf-parse/lib/pdf-parse.js');

/** Extract text from every page of a PDF buffer. Returns an array of strings (one per page). */
async function extractPages(buffer) {
  const pages = [];

  // Pass pdf.js its own exact-size copy. Node serves small buffers (under 4 KB) from a shared
  // memory pool, and the pdf.js bundled with pdf-parse reads the whole pool instead of just this
  // file, which makes small but valid PDFs fail with "bad XRef entry".
  const data = new Uint8Array(buffer);

  await pdfParse(data, {
    pagerender: async (pageData) => {
      const content = await pageData.getTextContent({ normalizeWhitespace: true });
      let lastY = null;
      let text = '';
      for (const item of content.items) {
        const y = item.transform[5];
        if (lastY === null || Math.abs(lastY - y) < 2) text += item.str;
        else text += '\n' + item.str;
        lastY = y;
      }
      pages.push(text);
      return text;
    },
  });

  return removeRepeatedLines(pages.map(cleanText));
}

function cleanText(text) {
  return text
    .replace(/\r/g, '')
    .replace(/-\n(?=[a-z])/g, '') // join words hyphenated across lines
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/**
 * Drop headers, footers and page numbers: lines in the first/last 3 lines of a page
 * whose text (digits ignored) repeats on most pages. Body text is never touched.
 */
function removeRepeatedLines(pages) {
  if (pages.length < 4) return pages;
  const EDGE = 3;
  const normalize = (line) => line.trim().replace(/\d+/g, '#').toLowerCase();
  const edgeKeys = (lines) => {
    const keys = new Set();
    lines.forEach((line, i) => {
      if ((i < EDGE || i >= lines.length - EDGE) && line.trim() && line.length < 100) keys.add(normalize(line));
    });
    return keys;
  };

  const counts = new Map();
  for (const page of pages) {
    for (const key of edgeKeys(page.split('\n'))) counts.set(key, (counts.get(key) || 0) + 1);
  }

  const threshold = pages.length * 0.6;
  return pages.map((page) => {
    const lines = page.split('\n');
    return lines
      .filter((line, i) => {
        const atEdge = i < EDGE || i >= lines.length - EDGE;
        return !(atEdge && line.length < 100 && (counts.get(normalize(line)) || 0) >= threshold);
      })
      .join('\n')
      .trim();
  });
}

module.exports = { extractPages };
