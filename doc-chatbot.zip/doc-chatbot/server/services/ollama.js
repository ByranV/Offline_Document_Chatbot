const config = require('../config');

async function request(method, urlPath, body) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), config.requestTimeoutMs);
  try {
    const res = await fetch(`${config.ollamaHost}${urlPath}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`Ollama ${urlPath} failed (${res.status}): ${text}`);
    }
    return await res.json();
  } catch (err) {
    if (err.name === 'AbortError') throw new Error('The language model took too long to respond.');
    if (err.cause && err.cause.code === 'ECONNREFUSED') {
      throw new Error(`Cannot reach Ollama at ${config.ollamaHost}. Is it running?`);
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

// nomic-embed-text expects a task prefix on the text it embeds.
const usesPrefix = /nomic-embed/i.test(config.embedModel);

/** Embed an array of strings. kind = 'document' (stored chunks) or 'query' (user question). */
async function embed(texts, kind = 'document') {
  const prefix = usesPrefix ? `search_${kind}: ` : '';
  const data = await request('POST', '/api/embed', {
    model: config.embedModel,
    input: texts.map((t) => prefix + t),
  });
  if (!data.embeddings || data.embeddings.length !== texts.length) {
    throw new Error('Unexpected response from the embedding model.');
  }
  return data.embeddings;
}

/** Send chat messages [{role, content}] and return the assistant's reply text. */
async function chat(messages) {
  const data = await request('POST', '/api/chat', {
    model: config.chatModel,
    messages,
    stream: false,
    options: { temperature: config.temperature, num_ctx: config.numCtx },
  });
  return data.message.content;
}

/** Returns { ok, missing: [model names that have not been pulled] } */
async function health() {
  const data = await request('GET', '/api/tags');
  const installed = (data.models || []).map((m) => m.name);
  const has = (name) => installed.some((n) => n === name || n.startsWith(`${name}:`));
  const missing = [config.chatModel, config.embedModel].filter((m) => !has(m));
  return { ok: missing.length === 0, missing };
}

module.exports = { embed, chat, health };
