const fs = require('fs/promises');
const crypto = require('crypto');
const config = require('../config');
const store = require('./vectorStore');
const { extractPages } = require('./pdfExtract');
const { chunkDocument } = require('./chunker');
const { embed } = require('./ollama');

const BATCH_SIZE = 16;

/** An error that retrying will not fix (corrupt or scanned PDF). */
function permanent(message) {
  const err = new Error(message);
  err.permanent = true;
  return err;
}

/**
 * Learn one PDF.
 *   source    the name shown in answers (path relative to the documents folder)
 *   fileMeta  { size, mtimeMs } of the file as it was when it was found to be stable
 *
 * If the file was learned before and its content changed, only the sections whose
 * text changed are embedded again; the rest reuse their stored vectors.
 * Searches keep using the old version until the new one is complete.
 */
async function ingestFile(filePath, source, fileMeta, onProgress = () => {}) {
  const buffer = await fs.readFile(filePath);
  const hash = crypto.createHash('sha256').update(buffer).digest('hex');
  const existed = store.has(source);

  if (store.matchesHash(source, hash)) {
    store.touchDocument(source, fileMeta.size, fileMeta.mtimeMs);
    return { source, status: 'unchanged' };
  }

  onProgress('Reading PDF');
  let pages;
  try {
    pages = await extractPages(buffer);
  } catch (err) {
    throw permanent(`${source}: could not read this PDF (${err.message})`);
  }

  const totalChars = pages.join('').replace(/\s/g, '').length;
  if (pages.length === 0 || totalChars / pages.length < 20) {
    throw permanent(`${source}: no extractable text found. It may be a scanned PDF. Run OCR on it first.`);
  }

  const chunks = chunkDocument(pages, {
    maxChars: config.chunkChars,
    overlapChars: config.chunkOverlapChars,
  });

  // Reuse vectors for sections whose page and text are unchanged.
  const known = store.getChunkVectors(source);
  const toEmbed = [];
  for (const c of chunks) {
    const vector = known.get(`${c.page}|${c.text}`);
    if (vector) c.vector = vector;
    else toEmbed.push(c);
  }

  for (let i = 0; i < toEmbed.length; i += BATCH_SIZE) {
    const batch = toEmbed.slice(i, i + BATCH_SIZE);
    // Prefix with the file name and page so the embedding captures where the text came from.
    const vectors = await embed(
      batch.map((c) => `${source}, page ${c.page}\n${c.text}`),
      'document'
    );
    batch.forEach((c, j) => (c.vector = vectors[j]));
    onProgress(`Learning section ${Math.min(i + BATCH_SIZE, toEmbed.length)} of ${toEmbed.length}`);
  }

  store.replaceDocument(source, hash, pages.length, chunks, fileMeta);
  return {
    source,
    status: existed ? 'updated' : 'added',
    pages: pages.length,
    chunks: chunks.length,
    reused: chunks.length - toEmbed.length,
  };
}

module.exports = { ingestFile };
