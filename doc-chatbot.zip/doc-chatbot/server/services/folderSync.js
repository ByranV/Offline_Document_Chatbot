const fs = require('fs/promises');
const fsSync = require('fs');
const path = require('path');
const config = require('../config');
const store = require('./vectorStore');
const { ingestFile } = require('./ingest');
const { health } = require('./ollama');

const STATUS_FILE = path.join(config.dataDir, 'sync-status.json');
const LOCK_FILE = path.join(config.dataDir, 'sync.lock');

// Anything that changes what is stored in the vectors must be part of this.
const FINGERPRINT = JSON.stringify({
  v: 1,
  embedModel: config.embedModel,
  chunkChars: config.chunkChars,
  chunkOverlapChars: config.chunkOverlapChars,
});

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const permanentFailures = new Map(); // source -> "size|mtime" of a file that can never be read
let statusData = { running: false, lastRun: null, files: {} };

// ---------- status (shared with the API process through a small file) ----------
function writeStatus() {
  try {
    fsSync.mkdirSync(config.dataDir, { recursive: true });
    fsSync.writeFileSync(STATUS_FILE, JSON.stringify(statusData));
  } catch (err) {
    /* status is informational only */
  }
}

function setFile(source, state, message = '') {
  statusData.files[source] = { state, message, updatedAt: new Date().toISOString() };
  writeStatus();
}

function readStatus() {
  try {
    return JSON.parse(fsSync.readFileSync(STATUS_FILE, 'utf8'));
  } catch (err) {
    return { running: false, lastRun: null, files: {} };
  }
}

// ---------- lock: only one process syncs at a time ----------
function isAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (err) {
    return err.code === 'EPERM';
  }
}

function acquireLock() {
  fsSync.mkdirSync(config.dataDir, { recursive: true });
  try {
    const fd = fsSync.openSync(LOCK_FILE, 'wx');
    fsSync.writeSync(fd, String(process.pid));
    fsSync.closeSync(fd);
    return true;
  } catch (err) {
    if (err.code !== 'EEXIST') throw err;
    try {
      const pid = parseInt(fsSync.readFileSync(LOCK_FILE, 'utf8'), 10);
      if (!pid || !isAlive(pid)) {
        // The process that held the lock crashed.
        fsSync.unlinkSync(LOCK_FILE);
        return acquireLock();
      }
    } catch (e) {
      /* lock vanished or unreadable: try again on the next run */
    }
    return false;
  }
}

function releaseLock() {
  try {
    fsSync.unlinkSync(LOCK_FILE);
  } catch (err) {
    /* already gone */
  }
}

// ---------- folder scanning ----------
async function listPdfs(dir, base = dir) {
  let entries;
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch (err) {
    // A missing top-level folder is an error, never "no documents" (that would erase everything).
    if (dir === base || err.code !== 'ENOENT') throw new Error(`Cannot read documents folder: ${err.message}`);
    return [];
  }

  const found = [];
  for (const entry of entries) {
    if (entry.name.startsWith('.') || entry.name.startsWith('~$')) continue; // hidden and Office temp files
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      found.push(...(await listPdfs(full, base)));
    } else if (/\.pdf$/i.test(entry.name)) {
      const st = await fs.stat(full);
      found.push({
        full,
        source: path.relative(base, full).split(path.sep).join('/'),
        size: st.size,
        mtimeMs: st.mtimeMs,
      });
    }
  }
  return found;
}

/** A file that is still being copied keeps changing size; wait and compare. */
async function isStable(file) {
  await sleep(config.stableDelayMs);
  try {
    const st = await fs.stat(file.full);
    return st.size === file.size && st.mtimeMs === file.mtimeMs;
  } catch (err) {
    return false;
  }
}

function describe(result) {
  if (result.status === 'added') return `learned (${result.pages} pages, ${result.chunks} sections)`;
  if (result.status === 'updated') {
    return `re-learned (${result.pages} pages, ${result.chunks} sections, ${result.reused} unchanged and reused)`;
  }
  return 'up to date';
}

// ---------- one sync pass ----------
/**
 * Compare the documents folder with what has been learned:
 *   new file        -> learn it
 *   changed file    -> learn it again (only the changed sections are re-embedded)
 *   deleted file    -> forget it (if AUTO_REMOVE is on)
 *   unchanged file  -> skipped without reading it
 */
async function syncOnce({ onProgress } = {}) {
  if (!acquireLock()) return { skipped: true };

  const summary = { added: [], updated: [], unchanged: 0, removed: [], waiting: [], failed: [] };
  statusData.running = true;
  writeStatus();

  try {
    if (store.ensureFingerprint(FINGERPRINT)) {
      permanentFailures.clear();
      console.log('[sync] Embedding model or chunk settings changed: learning all documents again.');
    }

    const files = await listPdfs(config.documentsDir);
    const present = new Set(files.map((f) => f.source));
    let modelsChecked = false;

    for (const file of files) {
      const key = `${file.size}|${file.mtimeMs}`;

      if (store.matchesFile(file.source, file.size, file.mtimeMs)) {
        summary.unchanged++;
        const current = statusData.files[file.source];
        if (!current || current.state !== 'ready') setFile(file.source, 'ready', 'up to date');
        continue;
      }
      if (permanentFailures.get(file.source) === key) continue; // known bad; retry only when the file changes

      if (!(await isStable(file))) {
        summary.waiting.push(file.source);
        setFile(file.source, 'waiting', 'Waiting for the file to finish copying');
        continue;
      }

      if (!modelsChecked) {
        const h = await health();
        if (!h.ok) throw new Error(`Missing Ollama models: ${h.missing.join(', ')}`);
        modelsChecked = true;
      }

      setFile(file.source, 'processing', 'Starting');
      try {
        const result = await ingestFile(
          file.full,
          file.source,
          { size: file.size, mtimeMs: file.mtimeMs },
          (message) => {
            setFile(file.source, 'processing', message);
            if (onProgress) onProgress(file.source, message);
          }
        );
        if (result.status === 'added') summary.added.push(file.source);
        else if (result.status === 'updated') summary.updated.push(file.source);
        else summary.unchanged++;
        setFile(file.source, 'ready', describe(result));
        if (result.status !== 'unchanged') console.log(`[sync] ${file.source}: ${describe(result)}`);
      } catch (err) {
        if (err.permanent) permanentFailures.set(file.source, key);
        summary.failed.push({ source: file.source, error: err.message });
        setFile(file.source, 'failed', err.permanent ? err.message : `${err.message} (will retry)`);
        console.error(`[sync] ${file.source}: FAILED - ${err.message}`);
      }
    }

    // Forget documents whose PDF has been deleted.
    if (config.autoRemove) {
      const stored = store.list();
      if (files.length === 0 && stored.length > 0) {
        console.warn(`[sync] The documents folder has no PDFs, so ${stored.length} stored document(s) were kept.`);
      } else {
        for (const doc of stored) {
          if (!present.has(doc.name)) {
            store.removeDocument(doc.name);
            summary.removed.push(doc.name);
            console.log(`[sync] ${doc.name}: forgotten (file deleted)`);
          }
        }
      }
    }
    for (const name of Object.keys(statusData.files)) {
      if (!present.has(name)) delete statusData.files[name];
    }

    return summary;
  } finally {
    statusData.running = false;
    statusData.lastRun = new Date().toISOString();
    writeStatus();
    releaseLock();
  }
}

/** Run a sync now and then every SYNC_INTERVAL_MS. Returns the timer. */
function startSync() {
  let busy = false;
  const tick = async () => {
    if (busy) return;
    busy = true;
    try {
      await syncOnce();
    } catch (err) {
      console.error(`[sync] ${err.message}`);
    } finally {
      busy = false;
    }
  };
  tick();
  return setInterval(tick, config.syncIntervalMs);
}

module.exports = { syncOnce, startSync, readStatus };
