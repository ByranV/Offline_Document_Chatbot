import React from 'react';
import './DocChat.css';

const REQUEST_TIMEOUT_MS = 180000; // local models can be slow

/**
 * Document chat widget. Class component, so it works on any React 16.x (no hooks needed).
 *
 * Props (all optional):
 *   apiBase      base URL of the chat API            default '/api/docchat'
 *   title        panel heading                       default 'Ask our documents'
 *   placeholder  input placeholder                   default 'Type your question'
 *   getHeaders   () => ({ Authorization: '...' })    add your own auth headers
 *   startOpen    open the panel on first render      default false
 */
class DocChat extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      open: !!props.startOpen,
      messages: [],
      input: '',
      loading: false,
    };
    this.listRef = React.createRef();
    this.inputRef = React.createRef();
    this.unmounted = false;

    this.toggle = this.toggle.bind(this);
    this.send = this.send.bind(this);
    this.clear = this.clear.bind(this);
    this.onChange = this.onChange.bind(this);
    this.onKeyDown = this.onKeyDown.bind(this);
  }

  componentDidUpdate(prevProps, prevState) {
    const list = this.listRef.current;
    if (list && (prevState.messages !== this.state.messages || prevState.loading !== this.state.loading)) {
      list.scrollTop = list.scrollHeight;
    }
    if (!prevState.open && this.state.open && this.inputRef.current) {
      this.inputRef.current.focus();
    }
  }

  componentWillUnmount() {
    this.unmounted = true;
  }

  toggle() {
    this.setState((s) => ({ open: !s.open }));
  }

  clear() {
    this.setState({ messages: [], input: '' });
  }

  onChange(e) {
    this.setState({ input: e.target.value });
  }

  onKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      this.send();
    }
  }

  async send() {
    const question = this.state.input.trim();
    if (!question || this.state.loading) return;

    // Send the recent conversation (without error bubbles) so follow-up questions make sense.
    const history = this.state.messages
      .filter((m) => !m.error)
      .slice(-6)
      .map((m) => ({ role: m.role, content: m.content }));

    this.setState((s) => ({
      messages: s.messages.concat({ role: 'user', content: question }),
      input: '',
      loading: true,
    }));

    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = setTimeout(() => controller && controller.abort(), REQUEST_TIMEOUT_MS);

    try {
      const res = await fetch(`${this.props.apiBase}/chat`, {
        method: 'POST',
        headers: Object.assign({ 'Content-Type': 'application/json' }, this.props.getHeaders()),
        body: JSON.stringify({ question, history }),
        signal: controller ? controller.signal : undefined,
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'The assistant could not answer. Try again.');
      this.addMessage({ role: 'assistant', content: data.answer, sources: data.sources || [] });
    } catch (err) {
      const message =
        err.name === 'AbortError' ? 'The assistant took too long to answer. Try again.' : err.message;
      this.addMessage({ role: 'assistant', content: message, error: true });
    } finally {
      clearTimeout(timer);
      if (!this.unmounted) this.setState({ loading: false });
    }
  }

  addMessage(message) {
    if (this.unmounted) return;
    this.setState((s) => ({ messages: s.messages.concat(message) }));
  }

  renderSources(sources) {
    if (!sources || sources.length === 0) return null;
    // One entry per file + page.
    const seen = {};
    const unique = sources.filter((s) => {
      const key = `${s.source}|${s.page}`;
      if (seen[key]) return false;
      seen[key] = true;
      return true;
    });
    return (
      <ul className="docchat__sources" aria-label="Sources">
        {unique.map((s) => (
          <li key={`${s.source}|${s.page}`}>
            {s.source}, page {s.page}
          </li>
        ))}
      </ul>
    );
  }

  render() {
    const { open, messages, input, loading } = this.state;
    const { title, placeholder } = this.props;

    return (
      <div className="docchat">
        {open && (
          <section className="docchat__panel" role="dialog" aria-label={title}>
            <header className="docchat__header">
              <h2 className="docchat__title">{title}</h2>
              <div className="docchat__header-actions">
                {messages.length > 0 && (
                  <button type="button" className="docchat__link" onClick={this.clear}>
                    Clear chat
                  </button>
                )}
                <button type="button" className="docchat__close" onClick={this.toggle} aria-label="Close chat">
                  &times;
                </button>
              </div>
            </header>

            <div className="docchat__messages" ref={this.listRef} aria-live="polite">
              {messages.length === 0 && (
                <p className="docchat__empty">
                  Ask a question and the answer will come from our documents, with the page it was found on.
                </p>
              )}
              {messages.map((m, i) => (
                <div
                  key={i}
                  className={`docchat__msg docchat__msg--${m.role}${m.error ? ' docchat__msg--error' : ''}`}
                >
                  <div className="docchat__text">{m.content}</div>
                  {m.role === 'assistant' && this.renderSources(m.sources)}
                </div>
              ))}
              {loading && (
                <div className="docchat__msg docchat__msg--assistant" aria-label="Searching the documents">
                  <span className="docchat__dots">
                    <span />
                    <span />
                    <span />
                  </span>
                </div>
              )}
            </div>

            <div className="docchat__composer">
              <textarea
                ref={this.inputRef}
                className="docchat__input"
                rows={2}
                value={input}
                placeholder={placeholder}
                onChange={this.onChange}
                onKeyDown={this.onKeyDown}
                maxLength={1000}
                disabled={loading}
              />
              <button
                type="button"
                className="docchat__send"
                onClick={this.send}
                disabled={loading || !input.trim()}
              >
                Send
              </button>
            </div>
          </section>
        )}

        <button
          type="button"
          className="docchat__launcher"
          onClick={this.toggle}
          aria-expanded={open}
        >
          {open ? 'Hide assistant' : 'Ask our documents'}
        </button>
      </div>
    );
  }
}

DocChat.defaultProps = {
  apiBase: '/api/docchat',
  title: 'Ask our documents',
  placeholder: 'Type your question',
  getHeaders: () => ({}),
  startOpen: false,
};

export default DocChat;
