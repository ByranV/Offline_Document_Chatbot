# Offline document chatbot

Answers questions from your own PDFs, running entirely on your own machine with
[Ollama](https://ollama.com). No subscription or cloud service is used.

Drop PDFs into a folder on the API server and they are learned automatically.
Change a file and it is re-learned (only the changed sections are re-embedded).
Delete a file and it is forgotten.

```
doc-chatbot/
├── server/
│   ├── router.js               Express router: POST /chat, admin upload/list/delete
│   ├── server.js               Standalone runner (starts the sync when AUTO_SYNC=true)
│   ├── config.js               All settings (read from .env)
│   ├── .env.example
│   ├── package.json
│   ├── services/
│   │   ├── folderSync.js       Watches the documents folder: learn / re-learn / forget
│   │   ├── ingest.js           PDF -> chunks -> embeddings -> store (reuses unchanged sections)
│   │   ├── vectorStore.js      File-backed vector search
│   │   ├── pdfExtract.js       PDF -> text per page, strips headers/footers
│   │   ├── chunker.js          Splits pages into overlapping chunks
│   │   ├── ollama.js           Calls the local models (embeddings + chat)
│   │   └── rag.js              Retrieve, build prompt, ask the model
│   ├── scripts/
│   │   ├── watch.js            Run the sync as its own process (npm run watch)
│   │   └── ingest-all.js       One-off sync (npm run ingest)
│   ├── documents/              PUT YOUR PDFs HERE (subfolders allowed)
│   └── data/                   store.json, sync-status.json, sync.lock
└── client/
    ├── DocChat.jsx             React 16 chat widget (class component)
    └── DocChat.css
```

## 1. Install Ollama and the models

Install Ollama for Windows from https://ollama.com, then:

```
ollama pull llama3.1:8b
ollama pull nomic-embed-text
```

## 2. Install the server (Node 18 or newer)

```
cd server
npm install
copy .env.example .env
```

Packages: `express`, `cors`, `dotenv`, `multer`, `express-rate-limit`, and
`pdf-parse` (pinned to 1.1.1; version 2 has a different API).

## 3. Choose how the folder sync runs

- **Simple:** `AUTO_SYNC=true` in `.env`, then `npm start`. The API process watches the folder.
- **Recommended under IIS:** `AUTO_SYNC=false`, and run `npm run watch` as its own process
  (for example as a Windows service via NSSM). A lock file stops two processes syncing at
  once, and the API reloads learned data automatically when it changes.

Then copy PDFs into `server/documents/` (or the folder in `DOCUMENTS_DIR`). They are learned
within about 10-15 seconds. `npm run ingest` does a one-off pass if you prefer.

## 4. Mount it in your existing Express API

```js
const createDocChatRouter = require('./doc-chatbot/server/router');

// Behind IIS/ARR, so rate limiting sees real client addresses:
// app.set('trust proxy', 1);

app.use('/api/docchat', createDocChatRouter({ authMiddleware: yourAuthMiddleware }));

// Only if you do NOT use server.js and want the API process to run the sync:
// require('./doc-chatbot/server/services/folderSync').startSync();
```

## 5. Add the widget to your React app

Copy `DocChat.jsx` and `DocChat.css` into `src/`:

```jsx
import DocChat from './DocChat';

<DocChat apiBase="/api/docchat" getHeaders={() => ({ Authorization: 'Bearer ' + token })} />
```

Override colours with the `--docchat-*` CSS variables on `.docchat`.

## Managing documents over HTTP (optional)

Set `ADMIN_API_KEY` in `.env`, then send it as the `x-admin-key` header:

```
curl -H "x-admin-key: KEY" -F "files=@a.pdf" -F "files=@b.pdf" http://localhost:4000/api/docchat/documents
curl -H "x-admin-key: KEY" http://localhost:4000/api/docchat/documents
curl -X DELETE -H "x-admin-key: KEY" http://localhost:4000/api/docchat/documents/a.pdf
```

Uploads and deletes only change the folder; the sync does the learning and forgetting.

## Tuning

- **Says "can't find that" too often:** lower `MIN_SCORE` (try 0.35) or raise `TOP_K`.
- **Answers from the wrong passages:** raise `MIN_SCORE`, lower `CHUNK_CHARS`.
- **Slow answers:** use a smaller model, or run Ollama on a machine with a GPU.
- **Scanned PDFs fail with "no extractable text":** OCR them first (e.g. OCRmyPDF).
- Changing `EMBED_MODEL` or the chunk size re-learns every document automatically.

## IIS notes

- Local models answer slowly: raise the request/proxy timeout for this route above 180 s.
- Keep Ollama bound to localhost (the default) so only your API can call it.
- The learned data is one JSON file, comfortable for a few hundred PDFs. For far larger
  collections, move to a real vector database.
